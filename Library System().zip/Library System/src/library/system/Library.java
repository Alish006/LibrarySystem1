package library.system;

import java.util.ArrayList;

public class Library {
    //Romance
    private String book1 = "Romeo and Juliet By William Shakespeare (1596) [9785002190393]";
     private String book2 = "Diary of a Memory By Nicholas Sparks (2008) [9785171072797]";
     private String book3 = "The Time Traveler's Wife By Audrey Niffenegger (2003) [9785389206526]";
     private String book4 = "Letter from a Stranger By Stefan Zweig (2011) [9785171607579]";

    //Thrillers and horror
    private String book5 = "Fortress By Robert Ford (2013) [9789152164488]";
    private String book6 = "House Without Memories By Donato Carrisi (2021) [9785389216723]";
    private String book7 = "Fight Club By Chuck Palahniuk (1996)  [9785170610235]";
    private String book8 = "Dexter in the Dark By Jeff Lindsay (2007)   [9785389231658]";

    //Fantasy and science fiction
    private String book9 = "Game of Thrones By George R. R. Martin (1996)  [9785271340871]";
    private String book10 = "The Lord of the Rings By J.R.R. Tolkien (1954) [9785170851324]";
    private String book11 = "Harry Potter and the Philosopher's Stone By J.K. Rowling (1997)  [9781408855898]";
    private String book12 = "The Chronicles of Narnia: The Lion, the Witch and the Wardrobe By C.S. Lewis (1950) [9780545945783]";

    // Travel
    private String book13 = "Around the World in Eighty Days By Jules Verne (1873)  [9781503215153]";
    private String book14 = "All Quiet on the Western Front  By Erich Maria Remarque (1928) [9780099532811]";
    private String book15 = "The Thorn Birds By Colleen McCullough (1943) [9780060129569]";
    private String book16 = "The Little Prince By Antoine de Saint-Exupéry (1943) [9781853261589]";

    //Humor
    private String book17 = "Fifty Shades of Black By Erik C. Johnson (2016) [9780345804044]";
    private String book18 = "Disc world series By Terry Pratchett (1983) [97818532615893] ";
    private String book19 = "Uncle Tom's Cabin By Harriet Beecher Stowe (1852) [9780140390032]";
    private String book20 = "Diary of a Wimpy Kid By Jeff Kinney (2007) [9780141324906]";




    public String getBook1() {
        return book1;
    }
    public String getBook2() {
        return book2;
    }
    public String getBook3() {
        return book3;
    }
    public String getBook4() {
        return book4;
    }
    public String getBook5() {
        return book5;
    }
    public String getBook6() {
        return book6;
    }
    public String getBook7() {
        return book7;
    }
    public String getBook8() {
        return book8;
    }
    public String getBook9() {
        return book9;
    }
    public String getBook10() {
        return book10;
    }
    public String getBook11() {
        return book11;
    }
    public String getBook12() {
        return book12;
    }
    public String getBook13() {
        return book13;
    }
    public String getBook14() {
        return book14;
    }
    public String getBook15() {
        return book15;
    }
    public String getBook16() {
        return book16;
    }
    public String getBook17() {
        return book17;
    }
    public String getBook18() {
        return book18;
    }
    public String getBook19() {
        return book19;
    }
    public String getBook20() {
        return book20;
    }

    private  int id1 = 1; //Mark
    private int id2 = 2; //Ali
    private int id3 = 3; //Emma
    private int id4 = 4; //Eva
    private int id5 = 5; //Mark
    private int id6 = 6; //Michael

    public int getId1(){
        return id1;
    }
    public int getId2(){
        return id2;
    }
    public int getId3(){
        return id3;
    }
    public int getId4(){
        return id4;
    }
    public int getId5(){
        return id5;
    }
    public int getId6(){
        return id6;
    }

}






